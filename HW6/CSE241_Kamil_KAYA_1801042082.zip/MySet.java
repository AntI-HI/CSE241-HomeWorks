/** 
 * Represents the Set interface.
 * @param E object-type to be held in collection. 
 * @author Kamil Kaya
 * @version 1.0
 * @since 2021-01-22
*/

public interface MySet<E> extends MyCollection<E> {


}
