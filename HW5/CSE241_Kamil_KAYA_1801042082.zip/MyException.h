#ifndef MYEXCEPTION_H_
#define MYEXCEPTION_H_

namespace KAYA_GTU {

class MyException{};

}
#endif