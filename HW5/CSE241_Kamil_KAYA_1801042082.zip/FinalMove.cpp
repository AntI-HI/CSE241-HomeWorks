#include "FinalMove.h"

int FinalMove::getRow() const { return row; }
int FinalMove::getCol() const { return col; }
void FinalMove::setRow(int newRow) { row = newRow; }
void FinalMove::setCol(int newCol) { col = newCol; }