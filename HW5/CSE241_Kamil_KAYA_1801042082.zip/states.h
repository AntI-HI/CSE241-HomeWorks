#ifndef STATES_H_
#define STATES_H_

namespace KAYA_GTU {
enum States{DOT, X, O}; // Enumerator represents the which state/value is the current location is.
                        // DOT represents empty location, X Represents oppenents move, O represents your move.
}

#endif