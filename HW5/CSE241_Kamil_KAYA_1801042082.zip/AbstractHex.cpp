#include "AbstractHex.h"

using namespace std;

namespace KAYA_GTU{

    // void AbstractHex::setSize(int newSize) {
    //     if(newSize < 5){
    //         cerr << "Sorry. You Entered the wrong value!! Terminating";
    //         exit(EXIT_FAILURE);
    //     }    
    //     reset();
    //     size = newSize;
    // }


}